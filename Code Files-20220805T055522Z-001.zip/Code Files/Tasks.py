import random


class Task:
    MIPS = 0
    SID = 0
    DID = 0
    task_deadline = 0
    taskId = 0

    def __init__(this, mips, source_did, dest_did, false):
        this.MIPS = mips
        this.SID = source_did
        this.DID = dest_did
        this.task_deadline = 0
        this.RSUFed = false

    def ComputeTaskCompletionDeadline(this, mips, cpu_freq):
        # seed(10)
        offset_list = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
        # network_Delay = random.randint(10,19)    # random no. b/w 1 & 8 some task are time sensitive and some ain't
        network_Delay = random.choice(offset_list)
        executionTime = (mips / cpu_freq)
        # network_Delay = random.randint(1,executionTime)
        task_deadline = executionTime + network_Delay  # to cater for n/w delays
        return task_deadline