

class offloadingInfo:
    def __init__(this, src_dev, src_dev_waitTime, dest_dev, dest_dev_cpu, dest_dev_waitTime,
                 taskStatus, task_id, taskSize, task_deadline, task_OffloadTime, taskrecv, nearbyRSU_ID,
                 src_dev_Tsk_Rcv, src_dev_rcvd_Tsk_Executed, src_dev_local_Computation, src_dev_Tsk_Offloaded,
                 src_dev_Tsk_Generated, dest_dev_Tsk_Rcv, dest_dev_rcvd_Tsk_Executed, dest_dev_local_Computation,
                 dest_dev_Tsk_Offloaded, dest_dev_Tsk_Generated, deadline_achieved):
        this.src_dev = src_dev
        this.src_dev_waitTime = src_dev_waitTime
        this.dest_dev = dest_dev
        this.dest_dev_cpu = dest_dev_cpu
        this.dest_dev_waitTime = dest_dev_waitTime
        this.taskStatus = taskStatus
        this.taskId = task_id
        this.taskSize = taskSize
        this.taskDeadline = task_deadline
        this.taskOffload_Time = task_OffloadTime
        this.taskRecvTime = taskrecv
        this.rsu_ID = nearbyRSU_ID

        this.src_dev_Tsk_Rcv = src_dev_Tsk_Rcv  # maintain while offloading
        this.src_dev_rcvd_Tsk_Executed = src_dev_rcvd_Tsk_Executed
        this.src_dev_local_Computation = src_dev_local_Computation
        this.src_dev_Tsk_Offloaded = src_dev_Tsk_Offloaded
        this.src_dev_Tsk_Generated = src_dev_Tsk_Generated

        this.dest_dev_Tsk_Rcv = dest_dev_Tsk_Rcv  # maintain while offloading
        this.dest_dev_rcvd_Tsk_Executed = dest_dev_rcvd_Tsk_Executed
        this.dest_dev_local_Computation = dest_dev_local_Computation
        this.dest_dev_Tsk_Offloaded = dest_dev_Tsk_Offloaded
        this.dest_dev_Tsk_Generated = dest_dev_Tsk_Generated
        this.deadline_achieved = deadline_achieved

       
        this.dest_dev_mode = 0
        this.src_dev_mode = 0
       