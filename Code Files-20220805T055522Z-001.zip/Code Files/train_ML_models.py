
import pandas as pd
import numpy as np
import pickle
import sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input,Dense,Dropout
import tensorflow as tf
# lstm model
from numpy import mean
from numpy import std
from numpy import dstack
from pandas import read_csv
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers import Dropout
from keras.layers import LSTM
#from keras.utils import to_categorical
from matplotlib import pyplot
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import cohen_kappa_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import auc
from sklearn.metrics import roc_curve
from matplotlib import pyplot as plt
from sklearn.metrics import log_loss
from sklearn.metrics import fbeta_score
import pickle
import joblib
import tensorflow as tf
import os


class Train_Machine_Learning_models:

    def Load_Training_Data(this):
        cwd = os.getcwd()
        training_data_set = pd.read_csv(".\\Training Dataset\\TrainingData.csv", low_memory=False)
        return training_data_set

    def Preprocess_Data(this,data):

        data = data.dropna()  # remove null values
        data.reset_index(drop=True)

        # remove un-processed tasks
        indexNames = data[data['Task_Recieving_Time'] == -1].index
        data.drop(indexNames, inplace=True)
        data.reset_index(drop=True)

        # remove source device features  and dest_dev mode
        #data = data.drop(
            #['src_dev', 'src_dev_WaitTime', 'src_dev_Tsk_Rcv', 'src_dev_rcvd_Tsk_Executed', 'src_dev_local_Computation',
             #'src_dev_Tsk_Generated', 'Src_dev_behavior', 'src_dev_mode', 'dest_dev_mode'], axis=1)

        # removing task id and dest dev
        data = data.drop(
            ['Offloaded_Task_Id', 'dest_dev','src_dev', 'src_dev_WaitTime', 'src_dev_Tsk_Rcv', 'src_dev_rcvd_Tsk_Executed', 'src_dev_local_Computation',
             'src_dev_Tsk_Generated', 'Src_dev_behavior', 'src_dev_mode', 'dest_dev_mode'], axis=1)


        #data.reset_index(drop=True)
        #print(data.head(5).to_string())
        #print(data.shape)

        return data

    def split_Data_input_features (this,training_data):

        # split the data into features and labels
        X_train = training_data.iloc[0:, 0:13]  # input features
        y_train = training_data.iloc[0:, 13:14]  # output label
        return X_train,y_train

    def Train_Logistic_Regression_model (this,training_data):

        X_train, y_train = model_obj.split_Data_input_features(training_data)

        # fit the model
        model = LogisticRegression(solver='lbfgs', max_iter=12000)

        # fit the training data
        model = model.fit(X_train, y_train)

        print("Logistic Regression model is trained...")
        return model     # return the trained model

    def Train_Decision_Tree_model(this, training_data):

        X_train, y_train = model_obj.split_Data_input_features(training_data)

        # fit the model
        model = DecisionTreeClassifier(criterion="entropy")  # this combo gave best results
        # fit the training data
        model = model.fit(X_train, y_train)

        print("Decision Tree model is trained")
        return model  # return the trained model



    def Train_Random_Forest_Classifier(this, training_data):

        X_train, y_train = model_obj.split_Data_input_features(training_data)

        # fit the model
        model = RandomForestClassifier(n_estimators=100, criterion='entropy', random_state=0)

        # fit the training data
        model.fit(X_train, y_train)
        print("Random Forest model is trained")
        return model


    def Train_Deep_Neural_Network(this, training_data):

        # split the data into features and labels
        X_train, y_train = model_obj.split_Data_input_features(training_data)

        # define the model
        model = Sequential()

        model.add(Dense(64, input_dim = X_train.shape[1], activation='relu'))
        model.add(Dense(16, activation='relu'))
        model.add(Dropout(0.2))
        model.add(Dense(8, activation='relu'))
        model.add(Dropout(0.2))
        model.add(Dense(1, activation='sigmoid'))

        model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

        model.fit(X_train, y_train,epochs=100,
                            batch_size=200)    # this returns a history object

        print ("Neural Network model is trained")
        return model  # return the trained model

    def Train_LSTM_model(this,training_data):

        # split the data into features and labels
        X_train, y_train = model_obj.split_Data_input_features(training_data)


        # reshape input to be 3D [samples, timesteps, features]
        X_train, y_train = np.array(X_train), np.array(y_train)
        X_train = X_train.reshape((X_train.shape[0], 1, X_train.shape[1]))

        opt = tf.keras.optimizers.Adam(lr=1e-3, decay=1e-5)
        model = Sequential()
        # model.add(LSTM(100, input_shape=(X_train.shape[1], X_train.shape[2])))
                                         # time steps , features

        model.add(LSTM(300, input_shape=(X_train.shape[1], X_train.shape[2]), activation='relu',
                       return_sequences=True))  # 128
        model.add(Dropout(0.2))

        model.add(LSTM(200, activation='relu'))  # 32
        model.add(Dropout(0.2))

        model.add(Dense(200, activation='relu'))
        model.add(Dropout(0.2))

        # model.add(Dense(2,activation='softmax'))
        model.add(Dense(1, activation='sigmoid'))


        model.add(Dense(1, activation='sigmoid'))

        # opt =tf.keras.optimizers.RMSprop(lr=0.01,rho=0.05,epsilon=1e-8,decay=0.0)   #discard

        model.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])
        # model.compile(loss='mean_squared_error', optimizer='adam')

        # fit network
        model.fit(X_train, y_train, epochs=100, batch_size=200,verbose=2,
                            shuffle = True)

        # evaluate the model
        scores = model.evaluate(X_train, y_train, verbose=0)
        print("%s: %.2f%%" % (model.metrics_names[1], scores[1] * 100))
        print("LSTM model is trained ")

        return model



model_obj = Train_Machine_Learning_models()
training_data = model_obj.Load_Training_Data()
training_data_proc = model_obj.Preprocess_Data(training_data)

   # Train the models

Logis_Reg_trained_model = model_obj.Train_Logistic_Regression_model(training_data_proc)
Decision_Tree_trained_model = model_obj.Train_Decision_Tree_model(training_data_proc)
Random_Forest_trained_model = model_obj.Train_Random_Forest_Classifier(training_data_proc)
Neural_Network_trained_model = model_obj.Train_Deep_Neural_Network(training_data_proc)
LSTM_trained_model = model_obj.Train_LSTM_model(training_data_proc)

# save the trained model on disk using pickle
#with open ('logistic_reg_model','wb') as f:
 #   pickle.dump(trained_model,f)

# using joblib dump all the trained models

joblib.dump(Logis_Reg_trained_model,'logistic_reg_model')

joblib.dump(Decision_Tree_trained_model,'decision_tree_model')

joblib.dump(Random_Forest_trained_model,'random_forest_model')

 # for deep models use the save method

Neural_Network_trained_model.save('neural_net_model')

LSTM_trained_model.save('LSTM_model')
