import joblib
import pandas as pd
import numpy as np
import keras
import helper_functions
from helper_functions import*
import os

class MachineLearningModels:


    def __init__(this):
        column_names = ["src_dev", "offloaded_task_id","Task_offloading_time","Task_Recieving_Time", "dest_dev", "predicted_label", "true_label"]
        this.ML_model_Prediction_History = pd.DataFrame(columns=column_names)

    def Load_Trained_ML_model(this,model_name):
        # retrieve the saved model from disk
        #cwd = os.getcwd()

        if model_name =='logistic regression':
          #model = joblib.load('logistic_reg_model')
          model = joblib.load('.\\Trained Machine Learning Models\\logistic_reg_model')

        elif model_name =='decision tree' :
          model = joblib.load('.\\Trained Machine Learning Models\\decision_tree_model')

        elif model_name =='random forest':
            model = joblib.load('.\\Trained Machine Learning Models\\random_forest_model')

        elif model_name =='neural network':
            model =  keras.models.load_model('.\\Trained Machine Learning Models\\neural_net_model')

        elif model_name =='LSTM':
            model = keras.models.load_model('.\\Trained Machine Learning Models\\LSTM_model')

        else:  # default
            model = joblib.load('.\\Trained Machine Learning Models\\logistic_reg_model')

        return model



    @staticmethod
    def feed_ML_model(model_obj):
            Data = helper_functions.DataHolder[-1]  # access the last entered record
            # make input data frame
            inputData = pd.DataFrame({
                                      #"Offloaded_Task_Id": [Data.TaskID],
                                      "Task_Size": [Data.TaskSize],
                                      #"dest_dev": [Data.dest_dev],
                                      "dest_dev_WaitTime": [Data.dest_dev_WaitTime],
                                      "Task_Offloading_Time": [Data.OffloadingTime],
                                      "Task_Recieving_Time": [Data.Recieving_Time],
                                      "task_deadline": [Data.task_deadline],
                                      "task_completion_time": [Data.task_completion_time],
                                      "Task_deadline_achieved": [Data.deadline_achieved],
                                      "Time_Deviated_from_Task_Deadline": [Data.TimeDeviation],
                                      "dest_dev_Tsk_Rcv": [Data.dest_dev_Tsk_Rcv],
                                      "dest_dev_Tsk_Rcv_Executed": [Data.dest_dev_Tsk_Rcv_Executed],
                                      "dest_dev_local_computation": [Data.dest_dev_local_computation],
                                      "dest_dev_Tsk_Generated": [Data.dest_dev_Tsk_Generated],
                                      "dest_dev_Tsk_offloaded": [Data.dest_dev_Tsk_offloaded],
                                      "Dest_dev_behavior": [Data.Dest_dev_behavior]})


            X_test = inputData.iloc[0:, 0:13]  # input features
            y_test = inputData.iloc[0:, 13:14]  # output label

            if helper_functions.selected_model == 'LSTM':
                # for LSTM reshape input
                X_test = np.asarray(X_test).astype(np.float32)
                                          # row(samples) ,steps, col(features)
                X_test = X_test.reshape((X_test.shape[0], 1, X_test.shape[1]))
                output = (helper_functions.ML_model.predict(X_test) > 0.5).astype("int32")
                output = int(output[0])  # predicted label

            else :
                output = helper_functions.ML_model.predict(X_test)
                output = int(output[0])  # predicted label

            #inputData = inputData.drop(['Offloaded_Task_Id', 'dest_dev'],axis=1)
            #inputData.reset_index(drop=True)


            #X_test = inputData.iloc[0:, 0:13]  # input features
            #y_test = inputData.iloc[0:, 13:14]  # output label



            #print(X_test.to_string())
            #X_test = np.array(X_test)
            #X_test = X_test.astype(np.float)






            #print("Prev output",output)


            #output = np.argmax(output, axis=1)
            #print("Output is :",output)



            #print("And now label is", output)
            #print("Device id :", Data.dest_dev, "Device true label = ", Data.Dest_dev_behavior,
             #     "Device predicted label is :", output)

            src_dev = Data.src_dev
            task_id = Data.TaskID
            dest_dev = Data.dest_dev
            true_label = Data.Dest_dev_behavior
            task_offload_time = Data.OffloadingTime
            task_rcv_time = Data.Recieving_Time

            # populate the list
            model_obj.Maintain_ML_model_Prediction_history(src_dev,task_id,task_offload_time,task_rcv_time,dest_dev,output,true_label)

            # for maintaining model prediction history




    def Maintain_ML_model_Prediction_history(this,src_dev,offloaded_task_id ,task_off_time,task_rcv_time,dest_dev ,predicted_label,true_label):

        # some check to ensure no repetition in data frame?
        new_input = { 'src_dev':src_dev,"offloaded_task_id":offloaded_task_id,"Task_offloading_time":task_off_time,
                      "Task_Recieving_Time":task_rcv_time,
                      "dest_dev":dest_dev,"predicted_label":predicted_label,"true_label":true_label}

        # append  each new entry

        this.ML_model_Prediction_History = this.ML_model_Prediction_History.append(new_input,ignore_index=True)