

class Dataset:   # class is used to create a dataset to perform ML
    def __init__(this,simulationTime,src_dev,src_dev_WaitTime,TaskID,taskSize,dest_dev,dest_dev_WaitTime,dest_cpu,
                 OffloadingTime,Recieving_Time,task_deadline,task_completion_time,RSU_ID,deadline_achieved,TimeDeviation,
                 src_dev_Tsk_Offloaded,src_dev_Tsk_Rcv,src_rcvd_Tsk_Executed,src_dev_local_Computation,src_dev_Tsk_Generated,dest_dev_Tsk_offloaded,dest_dev_Tsk_Rcv,
                dest_dev_Tsk_Rcv_Executed,dest_dev_local_computation,dest_dev_Tsk_Generated,Src_dev_behavior,Dest_dev_behavior,dest_dev_mode,src_dev_mode):

     this.simulationTime = simulationTime
     this.src_dev = src_dev
     this.src_dev_WaitTime = src_dev_WaitTime
     this.TaskID = TaskID
     this.TaskSize = taskSize
     this.dest_dev = dest_dev
     this.dest_dev_WaitTime = dest_dev_WaitTime
     this.dest_cpu =dest_cpu
     this.OffloadingTime = OffloadingTime
     this.Recieving_Time = Recieving_Time
     this.task_deadline =task_deadline
     this.task_completion_time =task_completion_time
     this.RSU_ID= RSU_ID
     this.deadline_achieved = deadline_achieved
     this.src_dev_Tsk_Offloaded =src_dev_Tsk_Offloaded
     this.src_dev_Tsk_Rcv =src_dev_Tsk_Rcv
     this.src_dev_local_Computation = src_dev_local_Computation
     this.src_dev_Tsk_Generated = src_dev_Tsk_Generated
     this.src_rcvd_Tsk_Executed = src_rcvd_Tsk_Executed
     this.TimeDeviation =TimeDeviation
     this.dest_dev_Tsk_offloaded = dest_dev_Tsk_offloaded
     this.dest_dev_Tsk_Rcv = dest_dev_Tsk_Rcv
     this.dest_dev_Tsk_Rcv_Executed = dest_dev_Tsk_Rcv_Executed
     this.dest_dev_local_computation = dest_dev_local_computation
     this.dest_dev_Tsk_Generated = dest_dev_Tsk_Generated
     this.Src_dev_behavior= Src_dev_behavior
     this.Dest_dev_behavior= Dest_dev_behavior
     
     this.dest_dev_mode = dest_dev_mode
     this.src_dev_mode = src_dev_mode
