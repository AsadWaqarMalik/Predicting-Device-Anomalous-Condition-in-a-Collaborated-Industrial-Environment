
import traci
import math
import queue
import threading
from threading import Timer
import traci.constants as tc
from random import seed
from random import random
import math
import helper_functions
from helper_functions import*
import Dataset
import Tasks
import offloadingInfo



class EdgeCompute:  # this class is under construction, purpose is to use the federation approach here
    def __init__(this, _xloc, _yloc, _id, _range, _cpu):
        this.x_axis = _xloc
        this.y_axis = _yloc
        this.id = _id
        this.range = _range
        this.cpu = _cpu
        this.que = queue.Queue(maxsize=9000)  # This is to hold the tasks for execution
        this.resultDel = queue.Queue(maxsize=100)  # This is to hold result for delivery
        this.waitingTime = 0
        this.executionTime = 0
        this.LocalAvgWT = 0  # local node average waiting time
        this.direct_delivery = 0
        this.oneHopDlv = 0
        this.twoHopDlv = 0
        this.failure = 0
        this.steps = 0.0  # time simulation
        this.countLocalExec = 0
        this.execution = 0
        this.totalTskRecv = 0
        this.taskFederated = 0
        this.FederatedTskReceived = 0
        this.nearbyDevicesReputationList = {}  # trust scores of nearby devices (id,TrustScore)
        this.Collection = {}  # to check which devices are within range of RSU

    def DeviceSelectionWaitingTimeBased(this):
        if len(this.nearbyDevicesReputationList) > 0:
            selected_device = list(this.nearbyDevicesReputationList)[0]
            sdev_wtime = Manager[selected_device].waitingTime
            for key, value in Manager.items():
                if value.waitingTime < sdev_wtime:
                    selected_device = key
                    sdev_wtime = Manager[selected_device].waitingTime
            return selected_device

   

    def DeviceSelectionTrustBased(this, source_dev_ID):
        #print("Device Selection Trust Based called for dev id:",source_dev_ID)
        # RSU selects most trusted device
        trusted_candidate_devices = []  # holds honest devices for current time frame
        src_dev_obj = Manager[source_dev_ID]
        nearby_Devices = src_dev_obj.Collection  # get the source device neigbors

        # remove the duplicates if any
        helper_functions.model_obj.ML_model_Prediction_History = helper_functions.model_obj.ML_model_Prediction_History.drop_duplicates()

        # check in prediction history df if it has the reputation
        if len(helper_functions.model_obj.ML_model_Prediction_History) > 0:  # predictions exist
            #print("Prediction history data exists ,checking for src_dev",source_dev_ID)
            for dev_id, y in nearby_Devices.items():  # iterate through the nearby device list
                dest_df = helper_functions.model_obj.ML_model_Prediction_History.loc[
                    helper_functions.model_obj.ML_model_Prediction_History['dest_dev'] == dev_id]

                # multiple interactions (majority voting)
                if len(dest_df) > 1:
                    dev_behavior = this.get_Majority_Voting(dev_id)  # majority opinion for this particular device

                    if dev_behavior == 0:  # majority says its honest
                        trusted_candidate_devices.append(dev_id)
                        #print("Majority says dev id :",dev_id ,"is honest")

                        # update the list if dev was declared malicious before
                        if dev_id in src_dev_obj.malicious_neigbors:
                            src_dev_obj.malicious_neigbors.remove(dev_id)
                            #print("Updating from malicous list")
                            #print("Veh ",dev_id,"is added in trusted candidates after majority voting")

                    else:  # majority says its malicious
                        if dev_id not in src_dev_obj.malicious_neigbors:  # preventing repeated entries
                            src_dev_obj.malicious_neigbors.append(dev_id)
                            #print("Device id " ,dev_id,"is already in src's dev ",source_dev_ID," malicous neigbors")

                else:
                    for i, row in dest_df.iterrows():  # iterate through the target device rows and not complete dataframe

                        if row['dest_dev'] == dev_id and row[ 'predicted_label'] == 0:  # within range device that is honest
                            trusted_candidate_devices.append(dev_id)
                            # print(*trusted_candidate_devices, sep=", ")
                            #print("A trsuted device is added in candidate list")

                        elif row['dest_dev'] == dev_id and row['predicted_label'] == 1:  # device is malicious
                            if dev_id not in src_dev_obj.malicious_neigbors:  # preventing repeated entries
                             src_dev_obj.malicious_neigbors.append(dev_id)
                             #print("A device",dev_id," is added in malicous neigbors list")

        #if len(trusted_candidate_devices) > 0:
         #print("Trusted neigbors:",list(trusted_candidate_devices))
         #print("Malcious neigbors are :",list(src_dev_obj.malicious_neigbors))
        return trusted_candidate_devices

    # else:
    # print("No record found for this list of devices")
    def get_Majority_Voting(this, dev_id):
       
        honest_counter = 0
        malicious_counter = 0
        dev_behavior = 0  # default in case of tie in opinion
        # remove the duplicates if any
        helper_functions.model_obj.ML_model_Prediction_History = helper_functions.model_obj.ML_model_Prediction_History.drop_duplicates()
        dest_df = helper_functions.model_obj.ML_model_Prediction_History.loc[helper_functions.model_obj.ML_model_Prediction_History['dest_dev'] == dev_id]
        # print("Getting majority opinion")
        #print (dest_df.head(20))

        for x, y in dest_df.iterrows():
            if y['predicted_label'] == 0:
                honest_counter = honest_counter + 1


            elif y['predicted_label'] == 1:
                malicious_counter = malicious_counter + 1


        # majority voting
        if honest_counter > malicious_counter:
            dev_behavior = 0
            #print("Aggregated opinion is for honest")


        elif malicious_counter > honest_counter:
            dev_behavior = 1
            #print("Aggregated opinion is for malicious for ",dev_id)

        return dev_behavior

    

    

    def AddLocalQueue(this, _tsk):
        this.LocalAvgWT = this.LocalAvgWT + this.waitingTime
        this.que.put(_tsk)
        this.ComputeWaitingTime(_tsk)
        # this.BuildDataset(_tsk,0.0,0.0, 0)

    def ComputeWaitingTime(this, _tsk):
        this.waitingTime = this.waitingTime + (_tsk.MIPS / this.cpu)

    def ExecuteTask(this):
        if this.que.empty() != True:
            tpk = this.que.get()
            this.execution = tpk.MIPS / this.cpu  # execution time of current task
            this.executionTime = this.executionTime + this.execution  # measure total execution time at each dev
            this.waitingTime = this.waitingTime - this.execution  # compute waiting time
            this.countLocalExec = this.countLocalExec + 1

            this.ResultDelivery(tpk)

    def UpdateExecutionTimer(this):
        if this.execution != 0:
            this.execution = this.execution - 1
        elif this.execution == 0:
            this.ExecuteTask()

    def RecvTask(this, _task):
        if _task.RSUFed == False:
            if this.OffloadInRSUFederation(_task) != True:
                this.AddLocalQueue(_task)
                this.totalTskRecv = this.totalTskRecv + 1
        elif _task.RSUFed == True:
            this.AddLocalQueue(_task)
            this.totalTskRecv = this.totalTskRecv + 1

    def ResultDelivery(this, _inExecTsk):

        if this.resultDel.qsize() > 0:
            _tt = this.resultDel.get()  # remove tsk from queue
            SrcVeh_object = Manager[_tt.SID]
            dlv_dist = math.sqrt(
                ((this.x_axis - SrcVeh_object.x_axis) ** 2) + ((this.y_axis - SrcVeh_object.y_axis) ** 2))
            # print (" distance after execution is", dlv_dist)
            if dlv_dist > 0 and dlv_dist < 150:
                this.direct_delivery = this.direct_delivery + 1
                # print (" direct delivery called ", this.direct_delivery)
            elif dlv_dist >= 150 and dlv_dist < 300:
                this.oneHopDlv = this.oneHopDlv + 1
                # print (" 1 HP delivery called ", this.oneHopDlv)
            elif dlv_dist >= 300 and dlv_dist <= 450:
                this.twoHopDlv = this.twoHopDlv + 1
            else:
                this.failure = this.failure + 1
        else:
            print("result delivery queue empty")

        # this.resultDel.put(_inExecTsk)

    def PrintStatRSU(this):
        print(this.id, " local compute ", this.countLocalExec, " Tsk Recv", this.totalTskRecv, " Pending Tsk ",
              this.que.qsize(), " Waiting Time = ", this.waitingTime, " Total execution time ", this.executionTime,
              " Task Federated ", this.taskFederated, " Federted task Recv ", this.FederatedTskReceived)

class RSUInfo:  
    def __init__(this, distance, wTime):
        this.distance = distance
        this.wtme = wTime
