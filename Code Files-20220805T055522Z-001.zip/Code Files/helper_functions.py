import math
import pandas as pd
import ML_helper
import numpy as np
from ML_helper import*
################************************************* GLOBAL VARIABLES ***********************************************************######


Manager = {}  # create empty dictionary to store the key value of every device
DataHolder = [] # create empty list to hold the offloading data
RSUManager = {}  # manage RSU
#selected_model = 'logistic regression'
#selected_model = 'decision tree'
#selected_model = 'neural network'
#selected_model = 'random_forest_model'
selected_model = 'LSTM'                       # choose model for Edge node

ML_model = model_obj.Load_Trained_ML_model(selected_model)


# simulation parameters
step = 0
simulation_time = 500 # simulation time
cold_start_duration = 300





########**************GLOBAL FUNCTIONS *************************########################

# To calculate communication delay

P = 30.0  # device transmit power (dBm)
Wmm = 4.0  # bandwidth of mm waves (GHz)
N0 = 174.0  # power spectral density of AGWN (dBm)
epsilon = 0.001  #
f = 2.4  # in GHz
x = 45  # packet size



def removeFileDuplicateRecords() :
    with open('Dataset.csv', 'r') as in_file, open('DatasetUnique.csv', 'w') as out_file:
        seen = set()  # set for fast O(1) amortized lookup
        for line in in_file:
            if line in seen: continue  # skip duplicate

            seen.add(line)
            out_file.write(line)

def  populate_Dataset ():

    # Generate Data set
    f = open("Dataset.csv", "w", encoding='UTF8', newline='')
    i = 0
    # f.write("time")
    # f.write(",")
    f.write("src_dev")
    f.write(",")
    f.write("src_dev_WaitTime")
    f.write(",")
    f.write("Offloaded_Task_Id")
    f.write(",")
    f.write("Task_Size")
    f.write(",")
    f.write("dest_dev")
    f.write(",")
    f.write("dest_dev_WaitTime")
    f.write(",")

    # f.write(",")
    # f.write("dest_dev_cpu")
    # f.write(",")
    f.write("Task_Offloading_Time")
    f.write(",")
    f.write("Task_Recieving_Time")
    f.write(",")
    f.write("task_deadline")
    f.write(",")
    f.write("task_completion_time")
    f.write(",")
    f.write("Task_deadline_achieved")
    f.write(",")
    f.write("Time_Deviated_from_Task_Deadline")
    f.write(",")
    # f.write("src_dev_Tsk_Offloaded")
    # f.write(",")
    f.write("src_dev_Tsk_Rcv")
    f.write(",")
    f.write("src_dev_rcvd_Tsk_Executed")
    f.write(",")
    f.write("src_dev_local_Computation")
    f.write(",")
    f.write("src_dev_Tsk_Generated")
    f.write(",")
    f.write("dest_dev_Tsk_Rcv")
    f.write(",")
    f.write("dest_dev_Tsk_Rcv_Executed")
    f.write(",")
    f.write("dest_dev_local_computation")
    f.write(",")
    f.write("dest_dev_Tsk_Generated")
    f.write(",")
    f.write("dest_dev_Tsk_offloaded")
    f.write(",")
    f.write("Src_dev_behavior")
    f.write(",")
    f.write("Dest_dev_behavior")
    f.write(",")
    f.write("src_dev_mode")
    f.write(",")
    f.write("dest_dev_mode")
    f.write("\n")

    # f.write(",")

    # f.write("RSU_Id")
    # f.write(",")

    #print("Size of dataset is ", len(DataHolder))
    for Data in DataHolder:
        # f.write(str(Data.simulationTime))
        # f.write(",")
        f.write(str(Data.src_dev))
        f.write(",")
        f.write(str(Data.src_dev_WaitTime))
        f.write(",")
        f.write(str(Data.TaskID))
        f.write(",")
        f.write(str(Data.TaskSize))
        f.write(",")
        f.write(str(Data.dest_dev))
        f.write(",")
        f.write(str(Data.dest_dev_WaitTime))
        f.write(",")
      
        # f.write(",")
        # f.write(str(Data.dest_cpu))
        # f.write(",")
        f.write(str(Data.OffloadingTime))
        f.write(",")
        f.write(str(Data.Recieving_Time))
        f.write(",")
        f.write(str(Data.task_deadline))
        f.write(",")
        f.write(str(Data.task_completion_time))
        f.write(",")
        f.write(str(Data.deadline_achieved))
        f.write(",")
        f.write(str(Data.TimeDeviation))
        f.write(",")
        # f.write(str(Data.src_dev_Tsk_Offloaded))
        # f.write(",")
        f.write(str(Data.src_dev_Tsk_Rcv))
        f.write(",")
        f.write(str(Data.src_rcvd_Tsk_Executed))
        f.write(",")
        f.write(str(Data.src_dev_local_Computation))
        f.write(",")
        f.write(str(Data.src_dev_Tsk_Generated))
        f.write(",")
        f.write(str(Data.dest_dev_Tsk_Rcv))
        f.write(",")
        f.write(str(Data.dest_dev_Tsk_Rcv_Executed))
        f.write(",")
        f.write(str(Data.dest_dev_local_computation))
        f.write(",")
        f.write(str(Data.dest_dev_Tsk_Generated))
        f.write(",")
        f.write(str(Data.dest_dev_Tsk_offloaded))
        f.write(",")
        f.write(str(Data.Src_dev_behavior))
        f.write(",")
        f.write(str(Data.Dest_dev_behavior))
        f.write(",")
        f.write(str(Data.src_dev_mode))
        f.write(",")
        f.write(str(Data.dest_dev_mode))
        f.write("\n")

        i += 1

    # f.write(str(Data.RSU_ID))
    # f.write(",")

    f.close()


def Load_Training_Data():
    # read the file
    training_data_set = pd.read_csv(".\\Training Dataset\\TrainingData.csv", low_memory=False)
    return training_data_set

def Preprocess_Data(data) :
    data = data.dropna()   # remove null values
    data.reset_index(drop = True)

    # remove un-processed tasks
    indexNames = data[data['Task_Recieving_Time'] == -1].index
    data.drop(indexNames ,inplace =True)
    data.reset_index(drop=True)

    # remove source device features  and dest_dev mode
    data = data.drop(['src_dev', 'src_dev_WaitTime', 'src_dev_Tsk_Rcv', 'src_dev_rcvd_Tsk_Executed', 'src_dev_local_Computation',
         'src_dev_Tsk_Generated', 'Src_dev_behavior', 'src_dev_mode', 'dest_dev_mode'], axis=1)

    data.reset_index(drop=True)

    return data


   # communication delay

def capacity(d, model):  # in Gbps
    if model == 'LOS':
        h = 69.6 + 20.9 * math.log10(d) + epsilon
    else:  # NLOS
        h = 69.6 + (33.0 * 10) * math.log10(d) + epsilon
    SNR = (P * h) / (N0 * Wmm)
    C = Wmm * math.log2(1.0 + SNR)
    return C

def thop(d, model):  # in microseconds
    return (x / capacity(d, model))


def addDeviceModes():
    # skewed distribution
    device_mode_list = []
    for i in range(0, 30): # 30%  (behaves as honest)
        x = 0
        device_mode_list.insert(i, x)

    for i in range(30,65):   # 35% (black hole /no response)
        x = 1
        device_mode_list.insert(i, x)

    for i in range(65, 100):         # 35% (Delayed response)
        x = 2
        device_mode_list.insert(i, x)

    #for i in range(90, 100):   # (Multiple patterns)
      #  x = 4
       # device_mode_list.insert(i, x)
    return device_mode_list

def addDeviceBehaviors(malicous_percentage):
    # skewed distribution
    device_behavior_list = []
    # malicous percentage

    for i in range(0, malicous_percentage): # malicous device percentage
        x = 1   # device is malicous
        device_behavior_list.insert(i, x)

    for i in range(malicous_percentage, 100):   # honest devciles
        x = 0    #  device is honest
        device_behavior_list.insert(i, x)

    return device_behavior_list

