#import pdb
import time
from typing import Any, Union
#import numpy as np
#import matplotlib.pyplot as plt
import random
#import numpy as np
import time

import os, sys
#sys.path.append(os.path.join(os.environ.get("SUMO_HOME"), 'tools'))
#sumoBinary = "D:\\SUMO Installer\\bin\\sumo-gui"
#'/usr/local/opt/sumo/share/sumo/bin'
#sumoCmd = [sumoBinary, "-c", "mahattan.sumocfg"]

import traci
import math
import queue
import threading
from threading import Timer
import traci.constants as tc
from random import seed
from random import random
import math
import helper_functions
from helper_functions import *
from helper_functions import step


import execute_trained_ML_models
from execute_trained_ML_models import *

import Device
import Edge
from Edge import EdgeCompute

# import ML libraries

import pandas as pd
import numpy as np
import keras
import pickle
import sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input,Dense,Dropout
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import cohen_kappa_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import auc
from sklearn.metrics import roc_curve
from matplotlib import pyplot as plt
from sklearn.metrics import log_loss
from sklearn.metrics import fbeta_score
import pickle
import joblib
import tensorflow as tf
import Device
from Device import Device



 # Access sumo
sys.path.append(os.path.join(os.environ.get("SUMO_HOME"), 'tools'))
sumoBinary = "D:\\SUMO Installer\\bin\\sumo-gui"
#'/usr/local/opt/sumo/share/sumo/bin'
sumoCmd = [sumoBinary, "-c", "Manhattan.sumocfg"]
#sumoCmd = [sumoBinary, "-c", "mahattan.sumocfg"]

#sumoCmd = [sumoBinary, "-c", "Manhattan.sumocfg","--step-length","1.5"]
traci.start(sumoCmd)


################************************************* GLOBAL VARIABLES ***********************************************************######



arbitrary_Manager = {}  # for malicous devices changing patterns
honest_devices_Manager = []
malicious_devices_Manager = []
malicious_devices_count = 0
total_task_offloaded_malicious = 0
arbitrary_mode_malicous_devices = 0

# Decision about tasks has been made
task_status_count = 0


     # xloc, yloc, id, range, CPU

edge1 = EdgeCompute(1487.97,2353.51,1, 300, 100.0)
edge2 = EdgeCompute(1644.86,1988.46,2, 300, 100.0)
edge3 = EdgeCompute(1856.67,2148.35,3, 300, 100.0)
edge4 = EdgeCompute(1972.88,2364.03,4, 300, 100.0)
edge5 = EdgeCompute(1687.97,2353.51,1, 300, 100.0)
edge6 = EdgeCompute(1887.83,2482.72,6, 300, 100.0)
edge7 = EdgeCompute(2165.81,2024.48,7, 300, 100.0)
edge8 = EdgeCompute(1677.97,2333.51,1, 300, 100.0)


RSUManager[1] = edge1
RSUManager[2] = edge2
RSUManager[3] = edge3
RSUManager[4] = edge4
RSUManager[5] = edge5
RSUManager[6] = edge6
RSUManager[7] = edge7
RSUManager[8] = edge8

# **************************************SUMO simulation code starts from here****************************#

# simulation parameters
import random


arbitrary_mode_time_slot = 29  # time duration for which malicious device behaves arbitrary (counter starts from zero)
seed(2027)
device_mode_list =  addDeviceModes()
max_malicious_devices = 30          # 10% (300 devices)
threshold = 0.669


# simulation loop

while helper_functions.step < simulation_time:
   
    traci.simulationStep()  # perform these steps at each simulation step


    for dev_id in traci.vehicle.getIDList():  # get devices in simulation via traCi

        position = traci.vehicle.getPosition(dev_id)

        # device has entered the simulation
        
        if dev_id in Manager:
            Dev_object = Manager[dev_id]
            Dev_object.PositionUpdate(position[0], position[1])    # update postion
            Dev_object.SimulationTime(helper_functions.step)

            
            # Task Generation
            if random.random() > threshold:  # for 300 devices
           
                Dev_object.EventGenerator()
           
            Dev_object.UpdateExecutionTimer()  # execution of tasks

            dev_mode_choice = random.choice(device_mode_list)  # randomly choose device mode
            # 30% mode 0
            # 35% mode 1
            # 35% mode 2

            # add arbitrary behavior for malicious device ( malicious devices will change patterns)
            # first time changing its pattern
            if Dev_object.deviceBehavior == 1 and Dev_object.arbitrary_counter == 0 and dev_id not in arbitrary_Manager:
                Dev_object.device_mode = dev_mode_choice  # malicious device changes its mode
                arbitrary_mode_malicous_devices = arbitrary_mode_malicous_devices + 1  # count of malicious devices going arbitrary
                arbitrary_Manager[dev_id] = Dev_object
                Manager[dev_id] = Dev_object  # add updated object (changed mode) in Manager
                # print(dev_id,"entered  mode", dev_mode_choice, "for 1st time at ",step)
                # traci.vehicle.setColor(dev_id,(0,255,0))   # green

                # device is already in arbitrary mode
            elif dev_id in arbitrary_Manager:
                Dev_object = Manager[dev_id]
                Dev_object.arbitrary_counter = Dev_object.arbitrary_counter + 1  # device completes cycle of 30 sec for each choosen mode
                Manager[dev_id] = Dev_object  # add updated object in Manager

                # device's one arbitrary cycle is completed
                if Dev_object.arbitrary_counter > arbitrary_mode_time_slot:
                    Dev_object.device_mode = 0  # device quits arbitrary mode after 30 sec and enters default mode 0
                    #Dev_object.device_mode = dev_mode_choice  # malicious device changes its mode

                    arbitrary_Manager.pop(dev_id)  # remove from arbitrary Manager
                    Manager[dev_id] = Dev_object
                # print(dev_id, "quits mode at",step)

            # some devices re-enter in arbitrary mode
            elif Dev_object.deviceBehavior == 1 and Dev_object.arbitrary_counter > arbitrary_mode_time_slot and dev_id not in arbitrary_Manager:

                Dev_object.arbitrary_counter = Dev_object.arbitrary_counter + 1  # re-enter arbitrary mode after 30 sec
                if Dev_object.arbitrary_counter > arbitrary_mode_time_slot + 30:
                    Dev_object.arbitrary_counter = 0  # behaves arbitrary for next 30 sec
                    Dev_object.device_mode = dev_mode_choice
                    Manager[dev_id] = Dev_object
                    arbitrary_Manager[dev_id] = Dev_object
                    # print(dev_id, "re-entered arbitrary mode at : ", step)

                Manager[dev_id] = Dev_object  # add updated counter device object

            Manager[dev_id] = Dev_object  # put this updated(pos) device obj in Manager

        # device is entering the simulation for first time
        else:

            # Randomly Decide Device Behavior
            deviceBehavior = 0
            if random.random() > 0.1 and malicious_devices_count < max_malicious_devices:
                deviceBehavior = 1  # 1 represents malicious behavior


            # Randomly decide computing capacity
            dev_cpu = 100
            if random.random() > 0.5:
                dev_cpu = 200

            dev = Device(dev_id, 10, dev_cpu, position[0], position[1], deviceBehavior)
            dev.SimulationTime(step)
            Manager[dev_id] = dev  # add in Manager after it has acquired it's initial trust score

            if dev.deviceBehavior == 1:
                malicious_devices_count = malicious_devices_count + 1
                # traci.vehicle.setColor(dev_id, (255, 0, 0))

         
    # print("Departed devices", traci.simulation.getDepartedNumber(), "at step :", step)
    # print("Devices have entered the network",traci.simulation.getDepartedIDList(),"at step:",step) #insertion in n/w

    # print ("Loaded devices", traci.simulation.getLoadedNumber())
    # print ("Devices in simulation", traci.vehicle.getIDCount(),"at step :",step)
    # print ("Devices have reached the destination :",traci.simulation.getArrivedIDList(),"at step :",step) # left n/w
    helper_functions.step += 1
    # print("Total Devices in manager :", len(Manager), "at time step :", step)

    # print ("ID present in network ", traci.vehicle.getIDList());




Total_offload = 0
Total_pending = 0
Total_recv = 0
Total_gen = 0
Total_compute = 0
AvgWaitintTime = 0
Ddelivery = 0
oneHopDel = 0
twoHopDel = 0
failureDel = 0

failureDelMal = 0  # Malicious devices won't deliver results
Total_mal_recv = 0
Total_pending_mal = 0
tasksInExecution = 0

Total_offload_rsu = 0
Total_pending_rsu = 0
Total_recv_rsu = 0
Total_compute_rsu = 0
AvgWaitintTime_rsu = 0
Ddelivery_rsu = 0
oneHopDel_rsu = 0
twoHopDel_rsu = 0
failureDel_rsu = 0
LocalExec = 0
MalLocalExec = 0

Total_deadlines_achieved = 0
local_deadlines_met = 0
reversed_offloading_decion = 0
total_task_rcv_mal_dev = 0
total_task_rcv_hon_dev = 0
total_task_offload_mal_dev = 0
total_task_offload_hon_dev = 0
total_rcvd_task_executed = 0
total_local_task_executed = 0
total_tsk_in_execution = 0
total_tasks_processed = 0

Total_communication_delay = 0

# tasks failures
total_packet_drop_failures = 0
total_black_hole_failures = 0
delayed_response_tasks = 0


#******* For new variable #***********
Total_rcvd_task_executed_mal = 0
Total_rcvd_task_executed_hon = 0

for x, y in Manager.items():

    # y.PrintStat()
    if y.deviceBehavior == 0:  # honest
        total_task_rcv_hon_dev = total_task_rcv_hon_dev + y.totalTskRecv
        total_task_offload_hon_dev = total_task_offload_hon_dev + y.offloadTsk
        #****
        Total_rcvd_task_executed_hon = Total_rcvd_task_executed_hon + y.src_rcvd_Tsk_Executed

    elif y.deviceBehavior == 1:  # malicious
        total_task_rcv_mal_dev = total_task_rcv_mal_dev + y.totalTskRecv
        total_task_offload_mal_dev = total_task_offload_mal_dev + y.offloadTsk
        # ****
        Total_rcvd_task_executed_mal = Total_rcvd_task_executed_mal + y.src_rcvd_Tsk_Executed



    Total_offload = Total_offload + y.offloadTsk
    Total_pending = Total_pending + y.que.qsize()  # local tasks?
    total_tsk_in_execution = total_tsk_in_execution + y.resultDel.qsize()
    delayed_response_tasks = delayed_response_tasks + y.DelayDelievery.qsize()  # how many tasks are in delay delievery queue?

    
    Total_recv = Total_recv + y.totalTskRecv
    Total_gen = Total_gen + y.GenTsk
    Total_compute = Total_compute + y.countLocalExec
    AvgWaitintTime = AvgWaitintTime + y.LocalAvgWT
    Ddelivery = Ddelivery + y.direct_delivery
    oneHopDel = oneHopDel + y.oneHopDlv
    twoHopDel = twoHopDel + y.twoHopDlv
    failureDel = failureDel + y.failure
    Total_offload_rsu = Total_offload_rsu + y.offloadTskRSU
    LocalExec = LocalExec + y.countLocalExec
    local_deadlines_met = local_deadlines_met + y.local_deadlines_met
    reversed_offloading_decion = reversed_offloading_decion + y.reversed_offloading_decision
    total_rcvd_task_executed = total_rcvd_task_executed + y.src_rcvd_Tsk_Executed
    total_local_task_executed = total_local_task_executed + y.local_tasks_executed
   

    total_tasks_processed = total_rcvd_task_executed + total_local_task_executed
    total_packet_drop_failures = total_packet_drop_failures + y.task_failure_packet_drop
    total_black_hole_failures = total_black_hole_failures + y.task_failure_black_hole
    
    # communication delay
    Total_communication_delay = Total_communication_delay+ y.communication_delay





sum = 0

#**********
print("Total Recived Tasks executed by honest devices:",Total_rcvd_task_executed_hon)
print("Total Recived Tasks executed by malicious devices:",Total_rcvd_task_executed_mal)





print("**************  Device Stats ****************")
#print("Data set Stats :")
#print("Data before pre-processing :", training_Data_set.shape)

#print("Data after pre-processing:", training_Data_set_proc.shape)

print("Total Tasks Generated : =", Total_gen)
print("Total offload to Devices =", Total_offload)
print("Total tasks locally executed =", LocalExec)
print("Total tasks Recv by the devices =", Total_recv)
print("Total tasks Pending =", Total_pending)
print("Total rcvd tasks executed", total_rcvd_task_executed)
print("Total local tasks executed", total_local_task_executed)
print("Total tasks in execution =", total_tsk_in_execution)
print("Total tasks processed (local+offload) =", total_tasks_processed)

print("Avg waiting time:", AvgWaitintTime/Total_gen)

print ("Direct delivery ", Ddelivery)
print ("One hop delivery ", oneHopDel)
print ("Two hop delivery ", twoHopDel)
print ("Failure delivery ", failureDel)
print("Total no. of malicious devices", malicious_devices_count)
print("Total no. of devices ", len(Manager))

print("Total Tasks recieved by honest devices", total_task_rcv_hon_dev)
print("Total Tasks offloaded by honest devices", total_task_offload_hon_dev)
print("Total Tasks recieved by malicous devices", total_task_rcv_mal_dev)
print("Total Tasks offloaded by malicious devices", total_task_offload_mal_dev)

print("Task completion rate for offloaded tasks: (Efficiency)",total_rcvd_task_executed /Total_offload)
print("Total packet drop failures:", total_packet_drop_failures)
print("Total black hole failures:", total_black_hole_failures)






# Generate Data set
populate_Dataset()


# Remove the duplicate values
#removeFileDuplicateRecords()



# save predictions data frame
helper_functions.model_obj.ML_model_Prediction_History.to_csv(".\\ML_model_Predictions.csv ",index=False)

traci.close()


