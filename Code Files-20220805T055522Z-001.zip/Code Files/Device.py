import helper_functions
from helper_functions import *
from helper_functions import step
import Dataset
from Dataset import *
import Tasks
from Tasks import Task
import offloadingInfo
from offloadingInfo import *
import Edge
from Edge import *
import traci
import math
import queue
import threading
from threading import Timer
import traci.constants as tc
from random import seed
from random import random
import math




class Device:

    # Added new parameter Device behavior
    # 1--> malicious & 0--> honest

    def __init__(this, id, range, cpu, x_axis, y_axis, deviceBehavior):
        this.id = id
        this.range = range
        this.cpu = cpu
        this.x_axis = x_axis
        this.y_axis = y_axis
        this.Collection = {}  # list of nearby devices(DevInfo obj)
        this.nearbyRSU = {}
        # timer = threading.Timer(2.0, this.gfg)
        # timer.start()
        this.execution = 0  # we will reduce this with ticks to show task execution
        this.countLocalExec = 0
        this.offloadTsk = 0
        this.GenTsk = 0
        this.totalTskRecv = 0
        this.que = queue.Queue(maxsize=9000)  # This is to hold the tasks for execution
        this.resultDel = queue.Queue(maxsize=100)  # This is to hold result for delivery
        this.waitingTime = 0
        this.executionTime = 0
        this.LocalAvgWT = 0  # local node average waiting time
        this.direct_delivery = 0
        this.oneHopDlv = 0
        this.twoHopDlv = 0
        this.failure = 0
        this.steps = 0.0  # time simulation
        this.offloadTskRSU = 0
        this.deviceBehavior = deviceBehavior
        this.offLoadInfoManager = {}  # to hold info about tasks were offloaded to which device and task status
        this.offTskNo = 0  # trying to associate task id with offloaded tasks
        this.src_rcvd_Tsk_Executed = 0
        this.local_tasks_executed = 0
        this.local_deadlines_met = 0
        this.DelayDelievery = queue.Queue(maxsize=100)  # malicious devices will give delayed response
        this.counter = 0
        this.reversed_offloading_decision = 0
        this.device_mode = 0  # 0--> malicious behaves as honest
        this.arbitrary_counter = 0  # after certain value arbitrary behavior changes back to fully malicous mode
        this.communication_delay = 0
        # to count task failures
        this.task_failure_packet_drop = 0
        this.task_failure_black_hole = 0
        # maintain list of malicious neigbors predicted by ML
        this.malicious_neigbors = []


    def CandidateDeviceSelectionWaitTime(this, trusted_candidate_devices, task_size, src_estimated_compl_time):
        if len(trusted_candidate_devices) > 0:
            #print("Candidate Device Selection waiting time based")
            # selected_device = list(this.Collection)[0]
            selected_device = list(trusted_candidate_devices)[0]
            # sdev_wtime = this.Collection[selected_device].wtme
            selected_device_obj = Manager[selected_device]
            selected_device_cpu = selected_device_obj.cpu
            sdev_wtime = selected_device_obj.waitingTime
            sdev_totalTime = sdev_wtime + (task_size / selected_device_cpu)

            for key in trusted_candidate_devices:
                if key != this.id:
                    selected_device_obj = Manager[key]
                    selected_device_cpu = selected_device_obj.cpu
                    wtime = selected_device_obj.waitingTime
                    totalTime = wtime + (task_size / selected_device_cpu)
                    if totalTime < sdev_totalTime and totalTime < src_estimated_compl_time:  # dest_dev wait time should be less than src_dev
                        selected_device = key
                        sdev_totalTime = totalTime

            if sdev_totalTime < src_estimated_compl_time and selected_device != this.id:
                return selected_device

            # also add if device is not predicted as malicious

    

  

    def Delay_Task_Delievery(this):
        if this.DelayDelievery.qsize() > 0:
            _tt = this.DelayDelievery.get()  # remove tsk from queue
            if _tt.SID != this.id:
                SrcDev_object = Manager[_tt.SID]
                dlv_dist = math.sqrt(
                    ((this.x_axis - SrcDev_object.x_axis) ** 2) + ((this.y_axis - SrcDev_object.y_axis) ** 2))
                # Adding offloading info
                TaskStatus = 0  # task processed
                SID = _tt.SID
                DID = _tt.DID
                taskId = _tt.taskId
                taskRecvTime = this.steps
                this.src_rcvd_Tsk_Executed = this.src_rcvd_Tsk_Executed + 1
                this.UpdateTaskOffLoadInfo(SID, DID, TaskStatus, taskId, taskRecvTime)
                this.counter = 0

                if 0 < dlv_dist < 150:
                    this.direct_delivery = this.direct_delivery + 1
                # print (" direct delivery called ", this.direct_delivery)
                elif 150 <= dlv_dist < 300:
                    this.oneHopDlv = this.oneHopDlv + 1
                # print (" 1 HP delivery called ", this.oneHopDlv)
                elif 300 <= dlv_dist <= 450:
                    this.twoHopDlv = this.twoHopDlv + 1
                else:  # device has gone far away
                    this.failure = this.failure + 1
                    print(f''' Task delievery failed for source dev{SID} for task id {taskId} ,from dest dev {DID},at time steps{taskRecvTime}''')

                #print("Result is finally delievered for",SID,"from dest dev",DID,"for taks id",taskId,"at time steps =",this.steps)

    def check_task_deadline(this):

        for x, y in this.offLoadInfoManager.items():  # checking if deadlines are met for offloaded task for every within range dev
            if y.taskRecvTime == -1:
                # print("No results recieved for previously offloaded tasks")
                x = 1

            else:
                taskCompletionTime = y.taskRecvTime - y.taskOffload_Time

                if taskCompletionTime > y.taskDeadline or taskCompletionTime < 0:  # deadline not achieved

                    deadline_achieved = 0
                    y.deadline_achieved = deadline_achieved

                elif taskCompletionTime < y.taskDeadline or taskCompletionTime == y.taskDeadline:  # deadline achieved

                    deadline_achieved = 1
                    y.deadline_achieved = deadline_achieved

   
    def BuildDataset(this, simulationTime, src_dev, src_dev_WaitTime, TaskID, taskSize, dest_dev, dest_dev_WaitTime,
                     dest_cpu,
                     OffloadingTime, Recieving_Time, task_deadline, task_completion_time, RSU_ID, deadline_achieved,
                     TimeDeviation, src_dev_Tsk_Offloaded,
                     src_dev_Tsk_Rcv, src_rcvd_Tsk_Executed, src_dev_local_Computation, src_dev_Tsk_Generated,
                     dest_dev_Tsk_offloaded, dest_dev_Tsk_Rcv, dest_dev_Tsk_Rcv_Executed,
                     dest_dev_local_computation,
                     dest_dev_Tsk_Generated, Src_dev_behavior, Dest_dev_behavior, dest_dev_mode,
                     src_dev_mode):

        data = Dataset.Dataset(simulationTime, src_dev, src_dev_WaitTime, TaskID, taskSize, dest_dev, dest_dev_WaitTime,
                       dest_cpu,
                       OffloadingTime, Recieving_Time, task_deadline, task_completion_time, RSU_ID, deadline_achieved,
                       TimeDeviation, src_dev_Tsk_Offloaded, src_dev_Tsk_Rcv, src_rcvd_Tsk_Executed,
                       src_dev_local_Computation, src_dev_Tsk_Generated, dest_dev_Tsk_offloaded, dest_dev_Tsk_Rcv,
                       dest_dev_Tsk_Rcv_Executed, dest_dev_local_computation,
                       dest_dev_Tsk_Generated, Src_dev_behavior, Dest_dev_behavior, dest_dev_mode,
                       src_dev_mode)

        DataHolder.append(data)

    def RsuSelectionDistanceBased(this):

        selected_RSU = list(this.nearbyRSU)[0]  # gives the first key
        srsu_dist = this.nearbyRSU[selected_RSU].distance
        for key, value in this.nearbyRSU.items():
            if value.distance < srsu_dist:
                selected_RSU = key
                srsu_dist = this.nearbyRSU[selected_RSU].distance
        return selected_RSU

    def SimulationTime(this, stp):
        this.steps = stp

    def UpdateTaskOffLoadInfo(this, TaskSender, TaskReciever, TaskStatus, taskId, taskRecvTime):
        # i need offload manager of sid

        dev_obj = Manager[TaskSender]  # we will get the task sender dev obj
        offLoadInfObje = dev_obj.offLoadInfoManager[taskId]
        offLoadInfObje.taskStatus = TaskStatus
        offLoadInfObje.taskRecvTime = taskRecvTime
        dev_obj.offLoadInfoManager[taskId] = offLoadInfObje

        # populate the Data base
        dev_obj.IsTaskRecievedWithinDeadline(taskId)
        # MachineLearningModels.feed_ML_model()
        helper_functions.model_obj.feed_ML_model(helper_functions.model_obj)
        # print( "Data is populated through Update info func at time step",this.steps,
        # "Data is for src_dev id:",dev_obj.id , "Dest_dev",this.id)

    def PrintOffLoadingStats(this):

        for x, y in this.offLoadInfoManager.items():
            # print("Task no",y.taskId, " sent from dev :",y.ts,"to device",y.tr,"Task Execution Status",y.taskStatus)
            print("Task no", y.taskId, " sent from dev :", y.taskSender, "to device", y.taskReciver,
                  "Task Offloading Time:", y.taskOffload_Time, "Task Recieving time",
                  y.taskRecvTime, "The deadline of task was ", y.taskDeadline)

    def IsTaskRecievedWithinDeadline(this, task_id):
        Total_deadlines_achieved = 0
        TimeDeviation = -1  # no response ,task wasn't executed
        for x, y in this.offLoadInfoManager.items():  # (use task id to avoid repetition)
         if y.taskId == task_id :
            if y.taskRecvTime != -1:  # to ensure we are not checking status for an un-processed task
                rsu_ID = y.rsu_ID
                # DestRSU_object = RSUManager[rsu_ID]
                taskCompletionTime = y.taskRecvTime - y.taskOffload_Time

                if taskCompletionTime > y.taskDeadline or taskCompletionTime < 0:  # deadline not achieved

                    deadline_achieved = 0
                    y.deadline_achieved = deadline_achieved

                    # add Dest_dev obj info
                    dest_dev_id = y.dest_dev
                    Dest_dev_obj = Manager[dest_dev_id]

                    Src_dev_behavior = this.deviceBehavior
                    Dest_dev_behavior = Dest_dev_obj.deviceBehavior

                    if (taskCompletionTime > 0):  # negative represents no response
                        TimeDeviation = taskCompletionTime - y.taskDeadline  # how much it deviates from the original deadline


                    elif (taskCompletionTime < 0):  # negative (black hole or packet was dropped)
                        TimeDeviation = -1
                        taskCompletionTime = -1

                    this.BuildDataset(this.steps, y.src_dev, y.src_dev_waitTime, y.taskId, y.taskSize, y.dest_dev,
                                      y.dest_dev_waitTime,
                                      y.dest_dev_cpu, y.taskOffload_Time, y.taskRecvTime, y.taskDeadline,
                                      taskCompletionTime, y.rsu_ID, deadline_achieved, TimeDeviation,
                                      y.src_dev_Tsk_Offloaded, y.src_dev_Tsk_Rcv, y.src_dev_rcvd_Tsk_Executed,
                                      y.src_dev_local_Computation, y.src_dev_Tsk_Generated, y.dest_dev_Tsk_Offloaded,
                                      y.dest_dev_Tsk_Rcv,
                                      y.dest_dev_rcvd_Tsk_Executed, y.dest_dev_local_Computation,
                                      y.dest_dev_Tsk_Generated, Src_dev_behavior, Dest_dev_behavior,
                                      y.dest_dev_mode, y.src_dev_mode)

                elif taskCompletionTime < y.taskDeadline or taskCompletionTime == y.taskDeadline:  # deadline achieved

                    deadline_achieved = 1
                    y.deadline_achieved = deadline_achieved
                    Total_deadlines_achieved = Total_deadlines_achieved + 1

                    dest_dev_id = y.dest_dev
                    Dest_dev_obj = Manager[dest_dev_id]

                    Src_dev_behavior = this.deviceBehavior
                    Dest_dev_behavior = Dest_dev_obj.deviceBehavior

                    if (taskCompletionTime > 0 and taskCompletionTime == y.taskDeadline):  # computes within deadline
                        TimeDeviation = taskCompletionTime - y.taskDeadline  # how much it deviates from the original deadline


                    elif (taskCompletionTime > 0 and taskCompletionTime < y.taskDeadline):  # computes before deadline
                        TimeDeviation = 0  # what can we use to represent this

                    this.BuildDataset(this.steps, y.src_dev, y.src_dev_waitTime, y.taskId, y.taskSize, y.dest_dev,
                                      y.dest_dev_waitTime,
                                      y.dest_dev_cpu, y.taskOffload_Time, y.taskRecvTime, y.taskDeadline,
                                      taskCompletionTime,
                                      y.rsu_ID, deadline_achieved, TimeDeviation,
                                      y.src_dev_Tsk_Offloaded, y.src_dev_Tsk_Rcv, y.src_dev_rcvd_Tsk_Executed,
                                      y.src_dev_local_Computation, y.src_dev_Tsk_Generated, y.dest_dev_Tsk_Offloaded,
                                      y.dest_dev_Tsk_Rcv,
                                      y.dest_dev_rcvd_Tsk_Executed, y.dest_dev_local_Computation,
                                      y.dest_dev_Tsk_Generated,
                                      Src_dev_behavior, Dest_dev_behavior, y.dest_dev_mode,
                                      y.src_dev_mode)

        return Total_deadlines_achieved

  

    def ComputeWaitingTime(this, _tsk):
        this.waitingTime = int(this.waitingTime + (_tsk.MIPS / this.cpu))

    # def ComputeExecutionTime(this, _tsk):

    # print ("Waiting time is ", this.waitingTime)

    def DeviceSelectionWaitingTimeBased(this, task_size, task_deadline, src_estimated_compl_time):

        this.WithInRangeDev()
        if len(this.Collection) > 0:
            selected_device = list(this.Collection)[0]
            # sdev_wtime = this.Collection[selected_device].wtme
            selected_device_obj = Manager[selected_device]
            selected_device_cpu = selected_device_obj.cpu
            sdev_wtime = selected_device_obj.waitingTime
            sdev_totalTime = sdev_wtime + (task_size / selected_device_cpu)

            for key, value in this.Collection.items():
                if key != this.id and key not in this.malicious_neigbors:  # ensure device is not malicious after cold start
                    if key in this.malicious_neigbors:
                        print("Cant select dev id :",key,"its declared malicious")
                    selected_device_obj = Manager[key]
                    selected_device_cpu = selected_device_obj.cpu
                    wtime = selected_device_obj.waitingTime
                    totalTime = wtime + (task_size / selected_device_cpu)
                    if totalTime < sdev_totalTime and totalTime < src_estimated_compl_time:  # dest_dev wait time should be less than src_dev
                        selected_device = key
                        sdev_totalTime = totalTime

            if sdev_totalTime < src_estimated_compl_time and selected_device != this.id \
                    and selected_device not in this.malicious_neigbors:
                return selected_device

            # check if dest_dev can meet the deadline

    # dest_dev = Manager[selected_device]
    # dest_cpu =dest_dev.cpu
    # dest_waitTime =dest_dev.cpu
    # expected_task_completion_time_dest #= (task_size / dest_cpu + dest_waitTime)
    # if expected_task_completion_time_dest <= task_deadline : # can destination meet my deadline

    def DeviceSelectionDistanceBased(this):
        # Collection holds both honest and malicious devices

        selected_device = list(this.Collection)[0]  # gives the first key
        sdev_dist = this.Collection[selected_device].distance
        for key, value in this.Collection.items():
            if key != this.id:
                if value.distance < sdev_dist:
                    selected_device = key
                    sdev_dist = this.Collection[selected_device].distance
        return selected_device  # id

    def PositionUpdate(this, x, y):
        this.x_axis = x
        this.y_axis = y
        # print ("Position Updated called", this.id, this.x_axis, this.y_axis)

    def WithInRange_RSU(this):
        #print("Size of RSU: ", len(RSUManager))
        for key, val in RSUManager.items():
            # print(x, y.id, y.x_axis, y.y_axis)
            distance = math.sqrt(
                ((this.x_axis - val.x_axis) ** 2) + ((this.y_axis - val.y_axis) ** 2))  # euclidean distance
            # if distance < 70:
            if distance < 300:
                rsu = RSUInfo(distance, val.waitingTime)
                this.nearbyRSU[val.id] = rsu
        # if no RSU is found add the default RSU i.e RSU 1


    def OffloadToRSU(this, _task):
        size = len(this.nearbyRSU)
        if size > 0:  # if rsu within range
            dest = list(this.nearbyRSU)[0]  # or first RSU selected
            _task.DID = dest

            DestRSU_object = RSUManager[dest]
            DestRSU_object.RecvTask(_task)
            this.offloadTskRSU = this.offloadTskRSU + 1
            RSUManager[dest] = DestRSU_object
            obj = this.nearbyRSU[dest]
            # this.BuildDataset(_task, obj.distance, obj.wtme ,2)
            print("Task send from ", this.id, " to RSU ", dest)
        # else:
        # this.AddLocalQueue(_task)

    def OffloadTask(this, _task, random_packet_drop):

        if len(this.Collection) > 0:  # now im giving priority to devices
            # print("offloading to devices...")
            # this.OffloadToDev(_task,offloading_choice_random_no)
            this.OffloadToDev(_task, random_packet_drop)

        # elif len(this.nearbyRSU) > 0:
        # this.OffloadToRSU(_task)
        else:
            # no nearby device was found
            this.AddLocalQueue(_task)
            this.countLocalExec = this.countLocalExec + 1
            this.reversed_offloading_decision = this.reversed_offloading_decision + 1  # means no  nearby devices was found so executing locally

            # print("No nearby device or RSU found,so locally executing,can't offload")

    def WithInRangeDev(this):

        # Check in Devices List
        for x, y in Manager.items():
            distance = math.sqrt(((this.x_axis - y.x_axis) ** 2) + ((this.y_axis - y.y_axis) ** 2))
            # if distance != 0 and distance < 50 and this.id != y.id:
            if distance != 0 and distance <= 150 and this.id != y.id:
                Device = DevInfo(distance, y.waitingTime)
                this.Collection[y.id] = Device

    def OffloadToDev(this, _task, random_packet_drop):

        size = len(this.Collection)  # Collection holds both honest and malicious dev info obj
        trusted_candiate_devices = []
        src_dev = this.id
        TaskStatus = 0  # 0 means un-processed
        # if size > 0:  # if device within range
        # dest = this.DeviceSelectionDistanceBased()  #returns selected device id
        src_estimated_compl_time = (_task.MIPS / this.cpu) + this.waitingTime
        # dest = this.DeviceSelectionWaitingTimeBased(_task.MIPS,_task.task_deadline,src_estimated_compl_time)
        # _task.DID = dest
        # Query Trust Score of device from nearbyRSU
        this.WithInRange_RSU()  # updates list mobility factor


        nearbyRSU_ID = 1 # default
        


       
        if  helper_functions.step > cold_start_duration:  # if rsu within range and cold start stage has passed
            #nearbyRSU_ID = this.RsuSelectionDistanceBased()
            nearbyRSU_Obj = RSUManager[nearbyRSU_ID]
            #print("Cold start duration is passed")

            # trusted_candiate_devices = nearbyRSU_Obj.DeviceSelectionTrustBased(src_dev).copy()
            trusted_candiate_devices = list(nearbyRSU_Obj.DeviceSelectionTrustBased(src_dev))  # returns a trusted nearby device id(atm wait time)

        if (len(trusted_candiate_devices)) > 0:  # trusted neigbors exist
            dest = this.CandidateDeviceSelectionWaitTime(trusted_candiate_devices, _task.MIPS,
                                                          src_estimated_compl_time)
            #again select on wait time

            _task.DID = dest
        # print("Previous device selected was :",dest,"Device after trust based is : ",dest_now)
        else:
            dest = this.DeviceSelectionWaitingTimeBased(_task.MIPS, _task.task_deadline, src_estimated_compl_time)
            _task.DID = dest
            #print("ML predictions do not exist at time steps",helper_functions.step)

        # Check in  devices list
        if dest in Manager:
            DestDev_object = Manager[dest]
            distance = math.sqrt(
                ((this.x_axis - DestDev_object.x_axis) ** 2) + ((this.y_axis - DestDev_object.y_axis) ** 2))

            #if distance <= 1:  # why ?
             #   print("Hello Distance is less than 1 :\n")
              #  this.AddLocalQueue(
               #     _task)  # no device found that can meet the deadline and can't meet the deadline locally
                #this.countLocalExec = this.countLocalExec + 1
                #this.reversed_offloading_decision = this.reversed_offloading_decision + 1

            #else:
            this.AddTaskOffloadInfo(_task, dest, random_packet_drop)


        else:
            this.AddLocalQueue(_task)  # no device found that can meet the deadline and can't meet the deadline locally
            this.countLocalExec = this.countLocalExec + 1
           

    def AddLocalQueue(this, _tsk):
        this.LocalAvgWT = this.LocalAvgWT + this.waitingTime
        this.que.put(_tsk)
        this.ComputeWaitingTime(_tsk)

        # this.countLocalExec = this.countLocalExec + 1
        # this.BuildDataset(_tsk,0.0,0.0, 0)

    def Offload_V1(this, _task):
        size = len(this.Collection)
        if size > 0:  # if device within range
            dest = list(this.Collection)[0]
            _task.DID = dest
            # tk = Task(400, this.id, dest)
            DestDev_object = Manager[dest]
            DestDev_object.RecvTask(_task)
            this.offloadTsk = this.offloadTsk + 1
            Manager[dest] = DestDev_object
            # print ("Task send from ", this.id, " to ", dest)
        else:
            this.AddLocalQueue(_task)
            this.countLocalExec = this.countLocalExec + 1

    def RecvTask(this, _task):
        this.AddLocalQueue(_task)
        this.totalTskRecv = this.totalTskRecv + 1

    def PrintRanges(this):
        for key, value in this.Collection.items():
            print(this.id, " distance with ", key, " is: ", value)

    def PrintStat(this):
        print(this.id, " Generated Tsk ", this.GenTsk, " local compute ", this.countLocalExec, " Offload = ",
              this.offloadTsk, " Tsk Recv", this.totalTskRecv, " Pending Tsk ", this.que.qsize(), " Waiting Time = ",
              this.waitingTime, " Total execution time ", this.executionTime)

    def EventGenerator(this):

        taskSize = 200  # randomly decide task size (regular)
        if random() > 0.5:
            taskSize = 400  # compute intensive
        tk = Tasks.Task(taskSize, this.id, 0, False)
        this.GenTsk = this.GenTsk + 1
        tk.task_deadline = tk.ComputeTaskCompletionDeadline(taskSize, this.cpu)  # compute Task Deadline


        # cpu_size= 100
        # if random.random() > 0.5:
        # cpu_size = 200
        # tk.task_deadline = tk.ComputeTaskCompletionDeadline(taskSize, cpu_size)  # compute Task Deadline
        task_execution_time = taskSize / this.cpu
        expected_task_completion_time = int(this.waitingTime + task_execution_time)
        # rand_no_dummy_task = random.random()
        random_packet_drop = random()
        # offloading_choice_random_no = random.random()   # to balance random() calls for malicious and honest
        # more tasks offload for non-malicious

        if this.deviceBehavior == 0 or this.deviceBehavior == 1 and this.device_mode == 0 or this.device_mode == 1 or this.device_mode == 2:  # malicious in arbitrary mode
            # malicious device in arbitrary mode 0,1 and 2 behaves like honest while offloading tasks
            if expected_task_completion_time > tk.task_deadline:
                # print (this.id , " Need to offload task")
                this.WithInRangeDev()  # Checks within range devices
                this.WithInRange_RSU()  # Checks within range RSUs2
                # this.OffloadTask(tk,offloading_choice_random_no)
                this.OffloadTask(tk, random_packet_drop)


            else:
                this.AddLocalQueue(tk)
                this.countLocalExec = this.countLocalExec + 1
                this.local_deadlines_met = this.local_deadlines_met + 1  # meets deadline locally
                # print (this.id, " Self-processed....!")


        elif this.deviceBehavior == 1 and this.device_mode == 3:  # malicious device in Dos attack
            this.WithInRangeDev()
            this.WithInRange_RSU()
            target_device = this.DeviceSelectionWaitingTimeBased(tk.MIPS,
                                                                   tk.task_deadline)  # Dos attack on target device
            # target device is honest
            if target_device in Manager:  # other case means no nearby device was found
                DID = target_device
                this.AddTaskOffloadInfo(tk, DID)
                # this.generate_Dos_Attack(target_device,rand_no_dummy_task)  # this current task is valid

            else:  # no nearby device found,current task is legitimate so it will add in local que
                this.AddLocalQueue(tk)
                this.countLocalExec = this.countLocalExec + 1
                this.local_deadlines_met = this.local_deadlines_met + 1  # meets deadline locally
                # print(this.id, " Self-processed....!")

    def AddTaskOffloadInfo(this, task, DID, random_packet_drop):

        # offloading information
        this.offTskNo = this.offTskNo + 1  # associating task id for offloaded task
        taskID = this.offTskNo  # representing id for offloaded tasks
        task.taskId = taskID
        this.offloadTsk = this.offloadTsk + 1  # counting the number of offloaded tasks
        # random_packet_drop = random.random()
        # count the current task as well

        # src_dev information
        src_dev = this.id
        src_dev_waitTime = this.waitingTime
        src_dev_Tsk_Rcv = this.totalTskRecv  # maintain while offloading
        src_dev_rcvd_Tsk_Executed = this.src_rcvd_Tsk_Executed
        src_dev_local_Computation = this.countLocalExec
        src_dev_Tsk_Offloaded = this.offloadTsk
        src_dev_Tsk_Generated = this.GenTsk

        # dest_dev information
        dest = DID
        if DID in Manager:
            DestDev_object = Manager[DID]

            # count the recieved task excluding this one
            dest_dev_Tsk_Rcv = DestDev_object.totalTskRecv  # maintain while offloading
            dest_dev_rcvd_Tsk_Executed = DestDev_object.src_rcvd_Tsk_Executed
            dest_dev_local_Computation = DestDev_object.countLocalExec
            dest_dev_Tsk_Offloaded = DestDev_object.offloadTsk
            dest_dev_Tsk_Generated = DestDev_object.GenTsk
            dest_cpu = DestDev_object.cpu
            dest_waitTime = DestDev_object.waitingTime
            TaskStatus = 0
            taskId = task.taskId
            taskSize = task.MIPS
            taskDeadline = task.task_deadline
            TaskOffloadTime = this.steps
            tskRcvTime = -1  # represents un processed , value updated in Result Delievery()
            nearbyRSU_ID = 0  # for the time being will update this when will be using this
            # rand_no = offloading_choice_random_no
            deadline_achieved = 0  # for this offloaded task

            # Add communication delay for each offloaded task
            distance = math.sqrt(
                ((this.x_axis - DestDev_object.x_axis) ** 2) + ((this.y_axis - DestDev_object.y_axis) ** 2))
            # if step>=500 :
            # print("distance =",distance,"at step :",step,"src-dev =",this.id ,"Dest dev =",DestDev_object.id)

            task_delay = thop(distance, 'LOS')
            this.communication_delay = this.communication_delay + task_delay

            # dest device is honest or malicious not in black hole mode
            if DestDev_object.deviceBehavior == 0 or DestDev_object.deviceBehavior == 1 and DestDev_object.device_mode == 0 or DestDev_object.device_mode == 2 or DestDev_object.device_mode == 3:  # target device is honest (it will become victim) or malicious
                # to represent real scenario and keeping the context , honest devices may drop the packet due to n/w errors

                if random_packet_drop > 0.99 and DestDev_object.deviceBehavior == 0:  # drop the packets
                    DestDev_object.totalTskRecv = DestDev_object.totalTskRecv + 1  # count the tasks but don't add in que
                    tskRcvTime = 0  # packet failed
                    offload_obj = offloadingInfo.offloadingInfo(src_dev, src_dev_waitTime, dest, dest_cpu, dest_waitTime,
                                                 TaskStatus, taskId, taskSize, taskDeadline, TaskOffloadTime,
                                                 tskRcvTime, nearbyRSU_ID, src_dev_Tsk_Rcv, src_dev_rcvd_Tsk_Executed,
                                                 src_dev_local_Computation,
                                                 src_dev_Tsk_Offloaded, src_dev_Tsk_Generated, dest_dev_Tsk_Rcv,
                                                 dest_dev_rcvd_Tsk_Executed,
                                                 dest_dev_local_Computation, dest_dev_Tsk_Offloaded,
                                                 dest_dev_Tsk_Generated,
                                                 deadline_achieved)
                    #print(DestDev_object.id, "dropped the packet due to network issues", "and its behavior is: ",
                          #DestDev_object.deviceBehavior)
                    
                    offload_obj.src_dev_mode = this.device_mode
                    offload_obj.dest_dev_mode = DestDev_object.device_mode
                    this.offLoadInfoManager[taskId] = offload_obj

                    # populate the Data base
                    this.IsTaskRecievedWithinDeadline(taskId)
                    # MachineLearningModels.feed_ML_model()
                    helper_functions.model_obj.feed_ML_model(model_obj)
                    #print("Data is populated through Add Task offload info at time step", this.steps)
                    DestDev_object.task_failure_packet_drop = DestDev_object.task_failure_packet_drop + 1  # count this failure for Dest_dev
                    Manager[DID] = DestDev_object
                    # how many tasks status is known
                    # task_status_count = task_status_count +1

                else:  # or malicious is not in black hole attack mode or devices is honest
                    DestDev_object.RecvTask(task)  # add in the local queue and count the tasks
                    offload_obj = offloadingInfo.offloadingInfo(src_dev, src_dev_waitTime, dest, dest_cpu, dest_waitTime,
                                                 TaskStatus, taskId, taskSize, taskDeadline, TaskOffloadTime,
                                                 tskRcvTime, nearbyRSU_ID, src_dev_Tsk_Rcv, src_dev_rcvd_Tsk_Executed,
                                                 src_dev_local_Computation,
                                                 src_dev_Tsk_Offloaded, src_dev_Tsk_Generated, dest_dev_Tsk_Rcv,
                                                 dest_dev_rcvd_Tsk_Executed,
                                                 dest_dev_local_Computation, dest_dev_Tsk_Offloaded,
                                                 dest_dev_Tsk_Generated, deadline_achieved)
                    
                    offload_obj.src_dev_mode = this.device_mode
                    offload_obj.dest_dev_mode = DestDev_object.device_mode
                    this.offLoadInfoManager[taskId] = offload_obj

            # malicious in black hole attack
            elif DestDev_object.deviceBehavior == 1 and DestDev_object.device_mode == 1 or DestDev_object.device_mode == 4:  # target device is malicious (no response)

                DestDev_object.totalTskRecv = DestDev_object.totalTskRecv + 1  # count the tasks but don't add in que
                tskRcvTime = 0  # no response, discard the tasks
                offload_obj = offloadingInfo.offloadingInfo(src_dev, src_dev_waitTime, dest, dest_cpu, dest_waitTime,
                                             TaskStatus, taskId, taskSize, taskDeadline, TaskOffloadTime,
                                             tskRcvTime, nearbyRSU_ID, src_dev_Tsk_Rcv, src_dev_rcvd_Tsk_Executed,
                                             src_dev_local_Computation,
                                             src_dev_Tsk_Offloaded, src_dev_Tsk_Generated, dest_dev_Tsk_Rcv,
                                             dest_dev_rcvd_Tsk_Executed,
                                             dest_dev_local_Computation, dest_dev_Tsk_Offloaded, dest_dev_Tsk_Generated,
                                             deadline_achieved)
                
                offload_obj.src_dev_mode = this.device_mode
                offload_obj.dest_dev_mode = DestDev_object.device_mode
                this.offLoadInfoManager[taskId] = offload_obj

                # populate the Data base
                this.IsTaskRecievedWithinDeadline(taskId)
                # MachineLearningModels.feed_ML_model()
                model_obj.feed_ML_model(model_obj)
                # print("Data is populated through Add Task offload info at time step",this.steps)
                DestDev_object.task_failure_black_hole = DestDev_object.task_failure_black_hole + 1  # count in Dest_dev failures

    def ResultDelivery(this, _inExecTsk):

        # print("In Result Delievery func")
        if this.resultDel.qsize() > 0:

            if this.counter > 10:
                this.Delay_Task_Delievery()  # now return the results when 5 other tasks have been executed

            this.counter = this.counter + 1

            if this.deviceBehavior == 1 and this.device_mode == 2 or this.device_mode == 4:  # represents delayed response
                # this.counter = this.counter + 1   #counter starts from 0
                _tt = this.resultDel.get()  # remove tsk from queue

                if _tt.SID != this.id:  # Delayed response
                    this.DelayDelievery.put(_tt)  # put the task in delay delievery queue

                    #print("Task sent from dev ",_tt.SID, "to dest dev",this.id,"is in Delayed response at time step",this.steps)
                    # if this.counter > 2 :
                    # this.Delay_Task_Delievery()

                elif _tt.SID == this.id:  # device's local task
                    this.local_tasks_executed = this.local_tasks_executed + 1  # how many locally tasks were executed

                    # or this.devilce mode =0

            elif this.deviceBehavior == 0 or this.deviceBehavior == 1 and this.device_mode == 0:
                # or this.device_mode==3 :   # malicious in arbitrary mode
                _tt = this.resultDel.get()  # remove tsk from queue

                if _tt.SID != this.id:  # some other device sent the task(not the local tasks)
                    SrcDev_object = Manager[_tt.SID]
                    dlv_dist = math.sqrt(
                        ((this.x_axis - SrcDev_object.x_axis) ** 2) + ((this.y_axis - SrcDev_object.y_axis) ** 2))

                    # Adding offloading info
                    TaskStatus = 1  # task processed
                    SID = _tt.SID
                    DID = _tt.DID
                    taskId = _tt.taskId
                    # taskSize=_tt.MIPS
                    # taskRecvTime = this.steps +this.AddTransmissionDelay(400)
                    taskRecvTime = this.steps  # Add the time at which result was delievered
                    # count the no. of recieved tasks executed recieved from  src_dev

                    this.src_rcvd_Tsk_Executed = this.src_rcvd_Tsk_Executed + 1
                    this.UpdateTaskOffLoadInfo(SID, DID, TaskStatus, taskId,
                                               taskRecvTime)  # calling this ensures task processing status is confirmed

                    if 0 < dlv_dist < 150:
                        this.direct_delivery = this.direct_delivery + 1
                    # print (" direct delivery called ", this.direct_delivery)
                    elif 150 <= dlv_dist < 300:
                        this.oneHopDlv = this.oneHopDlv + 1
                    # print (" 1 HP delivery called ", this.oneHopDlv)
                    elif 300 <= dlv_dist <= 450:
                        this.twoHopDlv = this.twoHopDlv + 1
                    else:                # device has gone far away (out of range)
                        this.failure = this.failure + 1
                        #print(f''' Task delievery failed for source dev{SID} for task id {taskId} ,from dest dev {DID},at time steps{taskRecvTime}''')

                elif _tt.SID == this.id:
                    this.local_tasks_executed = this.local_tasks_executed + 1
                # else:
                # this.failure = this.failure + 1
            # it won't deliever the results

        this.resultDel.put(_inExecTsk)

        # else:
        # this.resultDel.put(_inExecTsk)

   

    def ExecuteTask(this):

        if this.que.empty() != True:
            tpk = this.que.get()

            # tpk.SID !=this.id

            # this.TaskList.append(tpk)

            this.execution = tpk.MIPS / this.cpu  # execution time of current task
            this.executionTime = this.executionTime + this.execution  # measure total execution time at each dev
            this.waitingTime = this.waitingTime - this.execution  # compute waiting time
            # this.countLocalExec =  this.countLocalExec + 1

            # call reuslt delievery when current task is executed

            # put the results in que after it has been executed
            # this.resultDel.put(tpk)

            this.ResultDelivery(tpk)

            # t=Timer(interval=2,function=this.ResultDelivery,args=[tpk])
            # t.start()
            # print("Result Delievery Begins")
            # print (this.id, "Executing task...count=", this.countLocalExec)
            # else:
            # print ("No pending tasks at ", this.id)

    def UpdateExecutionTimer(this):
        if this.execution != 0:
            this.execution = this.execution - 1
            # this.execution = this.execution - 1.5
        elif this.execution == 0:
            this.ExecuteTask()

            # xloc, yloc, id, range, CPU


class DevInfo:  
    def __init__(this, distance, wTime):
        this.distance = distance
        this.wtme = wTime
        # this.TrustScore=TrustScore
